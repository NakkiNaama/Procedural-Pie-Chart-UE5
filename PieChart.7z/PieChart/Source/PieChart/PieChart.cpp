// Copyright Epic Games, Inc. All Rights Reserved.

#include "PieChart.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, PieChart, "PieChart" );
